﻿using System;

namespace BankApplication
{
    interface ICustomer
    {
        string City { get; set; }
        int CustomerId1 { get; set; }
        DateTime DateOfBirth1 { get; set; }
        string Gender { get; set; }
        string MobileNumber1 { get; set; }
        string Name1 { get; set; }
    }
}