﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApplication
{
    class Account : IAccount
    {
        int AccountId;
        int CustomerId;
        string AccountType;
        int DepositAmount;
        DateTime Account_start_date;
        string Account_status;
        private int accId;
        private string accType;
        private int amountToDeposit;

        public Account(int accountId, int customerId, string accountType, int depositAmount, DateTime account_start_date, string account_status)
        {
            AccountId = accountId;
            CustomerId = customerId;
            AccountType = accountType;
            DepositAmount = depositAmount;
            Account_start_date = account_start_date;
            Account_status = account_status;
        }

        public Account(int accId, int customerId, string accType, int amountToDeposit, DateTime account_start_date)
        {
            this.accId = accId;
            CustomerId = customerId;
            this.accType = accType;
            this.amountToDeposit = amountToDeposit;
            Account_start_date = account_start_date;
        }

        public Account(string accType)
        {
            this.accType = accType;
        }

        public int AccountId1
        {
            get
            {
                return AccountId;
            }

            set
            {
                AccountId = value;
            }
        }

        public int CustomerId1
        {
            get
            {
                return CustomerId;
            }

            set
            {
                CustomerId = value;
            }
        }

        public string AccountType1
        {
            get
            {
                return AccountType;
            }

            set
            {
                AccountType = value;
            }
        }

        public int DepositAmount1
        {
            get
            {
                return DepositAmount;
            }

            set
            {
                DepositAmount = value;
            }
        }

        public DateTime Account_start_date1
        {
            get
            {
                return Account_start_date;
            }

            set
            {
                Account_start_date = value;
            }
        }

        public string Account_status1
        {
            get
            {
                return Account_status;
            }

            set
            {
                Account_status = value;
            }
        }
    }
}
