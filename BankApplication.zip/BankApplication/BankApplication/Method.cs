﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApplication
{
    class Method : IMethod
    {
        List<ICustomer> lstcus = new List <ICustomer>();
        List<IAccount> lstacc = new List<IAccount>();

        public int AddCustomer(ICustomer cust)
        {
            lstcus.Add(cust);
            return cust.CustomerId1;
        }

        public bool CheckCustId(int CustomerId)
        {
            bool status = false;
            foreach(ICustomer cust in lstcus)
            {
                if(cust.CustomerId1 == CustomerId)
                {
                    status = true;
                }
            }
            return status;
        }

        public bool CheckAccType(string AccType)
        {
            if(AccType == "savings" || AccType == "current")
            {
                return true;
            }
            return false;
        }

        public bool checkIfExists(int AccId)
        {
            bool found = false;
            foreach(IAccount acc in lstacc)
            {
                if(acc.AccountId1 == AccId)
                {
                    Console.WriteLine("Account is already present");
                }
            }
            return found;
        }

        public int AddAccount(IAccount acc)
        {
            lstacc.Add(acc);
            return acc.AccountId1;
        }

        public void ViewByAccountType(string AccType1)
        {
            foreach(IAccount acc in lstacc)
            {
                if(acc.AccountType1 == AccType1)
                {
                    Console.WriteLine(" Account Id is: " + acc.AccountId1);
                    Console.WriteLine(" Account type is: " + acc.AccountType1);
                    Console.WriteLine(" Account start date is:" + acc.Account_start_date1);
                    Console.WriteLine(" Account status is:" + acc.Account_status1);
                    Console.WriteLine("Customer Id is:" + acc.CustomerId1);
                }
            }
        }

        public int DepositAmount(int AccId,int Amount)
        {
            foreach (IAccount acc in lstacc)
            {
                if(acc.AccountId1 == AccId)
                {
                    Amount = acc.DepositAmount1 + Amount;
                }
            }
            return Amount;
        }
    }
}
