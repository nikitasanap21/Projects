﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApplication
{
    class Customer : ICustomer
    {
        int CustomerId;
        string Name;
        DateTime DateOfBirth;
        string gender;
        string city;
        string MobileNumber;

        public Customer(int customerId, string name, DateTime dateOfBirth, string gender, string city, string mobileNumber)
        {
            CustomerId = customerId;
            Name = name;
            DateOfBirth = dateOfBirth;
            this.gender = gender;
            this.city = city;
            MobileNumber = mobileNumber;
        }

        public int CustomerId1
        {
            get
            {
                return CustomerId;
            }

            set
            {
                CustomerId = value;
            }
        }

        public string Name1
        {
            get
            {
                return Name;
            }

            set
            {
                Name = value;
            }
        }

        public DateTime DateOfBirth1
        {
            get
            {
                return DateOfBirth;
            }

            set
            {
                DateOfBirth = value;
            }
        }

        public string Gender
        {
            get
            {
                return gender;
            }

            set
            {
                gender = value;
            }
        }

        public string City
        {
            get
            {
                return city;
            }

            set
            {
                city = value;
            }
        }

        public string MobileNumber1
        {
            get
            {
                return MobileNumber;
            }

            set
            {
                MobileNumber = value;
            }
        }
    }
}
