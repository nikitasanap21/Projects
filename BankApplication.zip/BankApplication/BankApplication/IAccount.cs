﻿using System;

namespace BankApplication
{
    interface IAccount
    {
        int AccountId1 { get; set; }
        string AccountType1 { get; set; }
        DateTime Account_start_date1 { get; set; }
        string Account_status1 { get; set; }
        int CustomerId1 { get; set; }
        int DepositAmount1 { get; set; }
    }
}