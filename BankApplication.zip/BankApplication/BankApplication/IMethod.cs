﻿namespace BankApplication
{
    interface IMethod
    {
        int AddCustomer(ICustomer cust);
        bool CheckCustId(int CustomerId);
        bool CheckAccType(string AccType);
        int AddAccount(IAccount acc);
        void ViewByAccountType(string AccType);
        int DepositAmount(int AccId, int Amount);
        bool checkIfExists(int AccId);
    }
}