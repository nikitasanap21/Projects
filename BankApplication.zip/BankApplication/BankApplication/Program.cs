﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            try
            {
                int choice;
                int cnt = 0;
                int customerId = 5000;
                IMethod m = new Method();
                string AccStatus;
                int AccId = 1000;
                do
                {
                    Console.WriteLine("1.Add new Customer");
                    Console.WriteLine("2: Add new account for an existing customer");
                    Console.WriteLine("3: View all customer accounts by Accounttype");
                    Console.WriteLine("4: Deposit Amount \n");
                    Console.WriteLine("Enter your choice:");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1:
                            Console.WriteLine("Enter name:");
                            string name = Console.ReadLine();
                            Console.WriteLine("Enter Date of Birth(MM/DD/YYYY):");
                            DateTime DOB = Convert.ToDateTime(Console.ReadLine());
                            Console.WriteLine("Enter gender:");
                            string gender = Console.ReadLine();
                            Console.WriteLine("Enter city:");
                            string city = Console.ReadLine();
                            Console.WriteLine("Enter mobile no:");
                            string MobNo = Console.ReadLine();
                            ICustomer cust = new Customer(customerId, name, DOB, gender, city, MobNo);
                            m.AddCustomer(cust);
                            Console.WriteLine("Your customer Id is:"+customerId);
                            customerId++;
                            break;

                        case 2:
                            Console.WriteLine("Enter customer Id:");
                            customerId = Convert.ToInt32(Console.ReadLine());
                            bool check = m.CheckCustId(customerId);
                            if(check == true)
                            {
                                Console.WriteLine("Enter Account type:");
                                string AccType = Console.ReadLine();
                                bool check1 = m.CheckAccType(AccType);
                                if(check1 == true)
                                {
                                    Console.WriteLine("Your Account type is:"+AccType);
                                    Console.WriteLine("Enter the amount to be deposited");
                                    int AmountToDeposit = Convert.ToInt32(Console.ReadLine());
                                    if(AmountToDeposit >= 500)
                                    {
                                        DateTime account_start_date = DateTime.Now;
                                        AccStatus = "Active";
                                        m.checkIfExists(AccId);
                                        IAccount acc = new Account(AccId, customerId, AccType, AmountToDeposit, account_start_date);
                                        m.AddAccount(acc);
                                        Console.WriteLine("Your Account Id is:" + AccId);
                                        AccId++;
                                    }
                                    else
                                    {
                                        Console.WriteLine("Amount should be 500 or more than it");
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("The account should be current or savings");
                                }
                            }
                            else
                            {
                                Console.WriteLine("Customer Id does not exist");
                            }
                           break;

                        case 3:
                            Console.WriteLine("Enter account type");
                            string AccType1 = Console.ReadLine();
                            m.ViewByAccountType(AccType1);
                            break;

                        case 4:
                            Console.WriteLine("Enter customer ID");
                            customerId = Convert.ToInt32(Console.ReadLine());
                            bool status1 = m.CheckCustId(customerId);
                            if(status1 == true)
                            {
                                Console.WriteLine("Enter account Id");
                                AccId = Convert.ToInt32(Console.ReadLine());
                                Console.WriteLine("Enter account type");
                                AccType1 = Console.ReadLine();
                                bool check1 = m.CheckAccType(AccType1);
                                if(check1 == true)
                                {
                                    Console.WriteLine("Enter the amount to be deposited");
                                    int Amount = Convert.ToInt32(Console.ReadLine());
                                    if(Amount >= 500)
                                    {
                                        m.DepositAmount(AccId,Amount);
                                    }
                                    else
                                    {
                                        Console.WriteLine("Amount should be greater than or equal to 500");
                                    }
                                }
                                else
                                {
                                    Console.WriteLine("Invalid account type");
                                }
                            }
                            else
                            {
                                Console.WriteLine("Customer Id not exist in list");
                            }
                            break;

                        default:
                            Console.WriteLine("Invalid choice");
                            break;
                    }
                    Console.WriteLine("Do you want to continue (0/1)");
                    cnt = Convert.ToInt32(Console.ReadLine());
                } while (cnt >= 0);

            }
            catch(Exception e)
            {
                Console.WriteLine(e.Message);
            }
            finally
            {
                Console.WriteLine("Code Executed..");
            }
            Console.ReadKey();
        }
    }
}
